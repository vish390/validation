﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Validation_Code.Models;

namespace Validation_Code.Controllers
{
    public class EmployeeController : Controller
    {
        private static readonly List<string> _existingEmails = new()
    {
        "vishal@example.com",
        "test@demo.com",
        "foo@bar.com"
    };

        [HttpPost]
        [AllowAnonymous]
        public JsonResult IsEmailAvailable(string email)
        {
            Console.WriteLine("VIshal");
            bool available = !_existingEmails
                .Any(e => e.Equals(email, StringComparison.OrdinalIgnoreCase));

            return Json(available
                ? true
                : $"The email '{email}' is already in use.");
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new Employee());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Employee model)
        {
            // Ensure both attribute and IValidatableObject validations run
            var results = model.Validate(new ValidationContext(model));
            foreach (var vr in results)
                foreach (var name in vr.MemberNames)
                    ModelState.AddModelError(name, vr.ErrorMessage);

            if (ModelState.IsValid)
            {
                _existingEmails.Add(model.Email);
                IsEmailAvailable(model.Email);
                return RedirectToAction("Success");
            }

            return View(model);
        }

        public IActionResult Success()
        {
            return Content("Employee created ✅");
        }
    }
}
