﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Validation_Code.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 100 characters.")]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        [Remote("IsEmailAvailable", "Employee",
         HttpMethod = "POST",
         AdditionalFields = "__RequestVerificationToken",
         ErrorMessage = "Email is already in use.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Age is required.")]
        public int Age { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Age < 18)
                yield return new ValidationResult("Age must be at least 18.", new[] { nameof(Age) });

            if (DateOfBirth > DateTime.Now)
                yield return new ValidationResult("Date of Birth cannot be in the future.", new[] { nameof(DateOfBirth) });
        }
    }
}
